define(function (require) {
	var app = require('../../app');

	app.controller('pageCtrl', ['$scope', function ($scope) {

	}]);

});