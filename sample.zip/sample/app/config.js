define(function (require) {
	require('./home/config');
	require('./users/config');
	require('./index/config');
});