define(function (require) {
	// require('./home/config');
});