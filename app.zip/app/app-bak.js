(function () {
	'use strict';
	var app = angular.module('app', ['ui.router', 'oc.lazyLoad']);

	// config
	app.config(configure);

	app.constant('remoteUrl', 'http://localhost:3000');

	app.run(runner);

	/* @ngInject */
	function runner($state, $stateParams, $rootScope) {
		$rootScope.$state = $state;
		$rootScope.$stateParams = $stateParams;
	};

	/* @ngInject */
	function configure($stateProvider, $urlRouterProvider, $ocLazyLoadProvider) {

		$ocLazyLoadProvider.config({
			debug: false,
			events: true,
		});

		$urlRouterProvider.otherwise('/home/dashboard');

		$stateProvider
			.state('home', {
				url: '/home',
				templateUrl: 'main.html',
				resolve: {
					loadHomeDirective: loadHomeDirective
				}
			})
			.state('home.dashboard', {
				url: '/dashboard',
				templateUrl: 'dashboard/dashboard.html',
				controller: 'dashboardController',
				resolve: {
					loadDashboardRouterFiles: loadDashboardRouterFiles
				}
			})
			.state('home.chart', {
				url: '/chart',
				templateUrl: 'chart/chart.html',
				controller: 'chartController',
				resolve: {
					loadChartRouterFiles: loadChartRouterFiles
				}
			})
			.state('home.table', {
				url: '/table',
				templateUrl: 'table/table.html'
			})
			.state('home.form', {
				url: '/form',
				templateUrl: 'form/form.html'
			})
			// ui-elements
			.state('home.ui_panelsWells', {
				url: '/ui/panels-wells',
				templateUrl: 'ui-elements/panels-wells/panels-wells.html'
			})
			.state('home.ui_buttons', {
				url: '/ui/buttons',
				templateUrl: 'ui-elements/buttons/buttons.html'
			})
			.state('home.ui_notifications', {
				url: '/ui/notifications',
				templateUrl: 'ui-elements/notifications/notifications.html'
			})
			.state('home.ui_typography', {
				url: '/ui/typography',
				templateUrl: 'ui-elements/typography/typography.html'
			})
			.state('home.ui_icons', {
				url: '/ui/icons',
				templateUrl: 'ui-elements/icons/icons.html'
			})
			.state('home.ui_grid', {
				url: '/ui/grid',
				templateUrl: 'ui-elements/grid/grid.html'
			})
			// sample
			.state('home.sample_blank', {
				url: '/sample/blank',
				templateUrl: 'sample/blank/blank.html'
			})
			.state('home.sample_login', {
				url: '/sample/login',
				templateUrl: 'sample/login/login.html'
			})
			// thrid level
			.state('home.ui_demo_first', {
				url: '/ui/demo/first',
				templateUrl: 'sample/blank/blank.html'
			})
			.state('home.ui_demo_second', {
				url: '/ui/demo/second',
				templateUrl: 'sample/login/login.html'
			})
			.state('home.ui_demo_thrid', {
				url: '/ui/demo/thrid',
				templateUrl: 'dashboard/dashboard.html',
			})
			// end

		/* @ngInject */
		function loadHomeDirective($ocLazyLoad) {
			return $ocLazyLoad.load({
				name: 'app',
				files: [

					'common/common.directive.js',
					'common/common.service.js',

					// user
					'user/user.service.js',

					// notification
					'notification/notification.service.js',
					'notification/notification.controller.js',
					'notification/notification.directive.js',

					//sidebar
					'sidebar/sidebar.service.js',
					'sidebar/sidebar.controller.js',
					'sidebar/sidebar.directive.js',

					// header
					'header/header.directive.js'
				]
			});
		}
		/* @ngInject */
		function loadDashboardRouterFiles($ocLazyLoad) {
			return $ocLazyLoad.load({
				name: 'app',
				files: [
					'dashboard/dashboard.controller.js',
					'dashboard/dashboard.directive.js'
				]
			});
		}

		/* @ngInject */
		function loadChartRouterFiles($ocLazyLoad) {
			return $ocLazyLoad.load({
					name: 'app',
					files: [
						'chart/chart.controller.js'
					]
				}),
				$ocLazyLoad.load({
					name: 'chart.js',
					files: [
						'../bower_components/angular-chart.js/dist/angular-chart.min.css',
						'../bower_components/angular-chart.js/dist/angular-chart.min.js'
					]
				});
		}

	}
})();