(function () {
	'use strict';

	angular.module('app')
		.directive('timeline', timeline)
		.directive('notifications', notifications)
		.directive('chat', chat);

	function timeline() {
		return {
			templateUrl: 'dashboard/timeline.html',
			restrict: 'AE',
			replace: true
		}
	}

	function notifications() {
		return {
			templateUrl: 'dashboard/notifications.html',
			restrict: 'AE',
			replace: true,
		}
	}

	function chat() {
		return {
			templateUrl: 'dashboard/chat.html',
			restrict: 'AE',
			replace: true,
		}
	}
})();