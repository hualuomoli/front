(function (angular) {
	'use strict';

	angular.module('app')
		.controller('dashboardController', dashboardController);

	/* @ngInject */
	function dashboardController($scope, userService) {

	}

})(window.angular);