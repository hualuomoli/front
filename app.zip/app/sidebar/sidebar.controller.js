(function ($, angular) {
	'use strict';

	angular.module('app')
		.controller('sidebarController', sidebarController);

	/* @ngInject */
	function sidebarController($scope, $state, sidebarService, userService) {
		$scope.menus = [];

		$scope.$on('init', init);

		$scope.toggleClass = toggleClass;
		$scope.goMenu = goMenu;

		// if (userService.isLogin)
		getAll();

		//
		function getAll() {
			return sidebarService.getAll()
				.then(function (response) {
					var data = response.data;
					$scope.menus = transferData(data);
				});
		};

		function init() {
			$('.metisMenu').metisMenu();
		}

		function goMenu(menuCode, parentMenuCode) {
			console.log(menuCode);
			$state.go('home.' + menuCode);
		}

		function transferData(data) {
			return data;
		}

		function toggleClass(key) {
			$(key).slideToggle(400);
		}

	}

})(jQuery, window.angular);