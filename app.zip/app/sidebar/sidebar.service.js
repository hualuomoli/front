(function (angular) {
	'use strict';

	angular.module('app')
		.service('sidebarService', sidebarService);

	/* @ngInject */
	function sidebarService($http, commonService) {

		return {
			getAll: getAll
		}

		function getAll() {
			return commonService.getData('data/sidebar/menus.json');
		}

	}

})(window.angular);