(function () {
	'use strict';

	angular.module('app')
		.directive('headerSidebar', headerSidebar)
		.directive('sidebarSearch', sidebarSearch)

	function headerSidebar() {
		return {
			templateUrl: 'sidebar/sidebar.html',
			controller: 'sidebarController',
			restrict: 'AE',
			replace: true
		}
	}

	function sidebarSearch() {
		return {
			templateUrl: 'sidebar/sidebar-search.html',
			scope: {},
			controller: 'sidebarController',
			restrict: 'E',
			replace: true,
		}
	}
})();