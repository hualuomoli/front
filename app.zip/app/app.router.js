define(function (require) {
	var app = require('./app.module');

	app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
		$urlRouterProvider.otherwise('/home');

		// $stateProvider
		//     .state('home', {
		//         url: '/home',
		//         templateUrl: 'home/home.html',
		//         // new attribute for ajax load controller 
		//         controllerUrl: 'home/homeCtrl',
		//         controller: 'homeCtrl'
		//     })
		//     .state('users', app.route({
		//         url: '/users',
		//         templateUrl: 'users/users.html',
		//         // new attribute for ajax load controller 
		//         controllerUrl: 'users/usersCtrl',
		//         controller: 'usersCtrl',
		//         // load more controllers, services, filters, ... 
		//         dependencies: ['services/usersService']
		//     }));
	}]);
});