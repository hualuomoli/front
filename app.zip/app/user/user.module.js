(function () {
	angular.module('bz.user', []);
})();