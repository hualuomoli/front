(function () {
	angular.module('bz.home')
		.run(appRun);

	/* @ngInject */
	function appRun(routehelper) {
		routehelper.configureRoutes(getRoutes());
	}

	function getRoutes() {
		return [{
			state: 'home',
			url: '/',
			config: {
				url: '/',
				templateUrl: 'home/home.html',
				controller: 'homeCtrl',
				controllerAs: 'vm'
			}
		}];
	}

})();