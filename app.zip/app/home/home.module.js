(function () {
	'use strict';

	angular.module('bz.home', []);
})();