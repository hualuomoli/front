(function ($, angular) {
	'use strict';

	angular.module('app')
		.directive('onFinishRender', onFinishRender);

	/* @ngInject */
	function onFinishRender($timeout) {
		return {
			restrict: 'A',
			link: function (scope, element, attr) {
				$timeout(function () {
					if (attr.onFinishRender) {
						scope.$emit(attr.onFinishRender);
					} else {
						scope.$emit('init');
					}
				});
			}
		};
	}

})(jQuery, window.angular);