(function ($, angular) {
	'use strict';

	angular.module('app')
		.factory('commonService', commonService);

	/* @ngInject */
	function commonService($http, remoteUrl) {
		return {
			getData: getData,
		}

		function getData(url) {
			return $http.get('../' + url);
		}

		function getRemotePath(url) {
			return path.join(remoteUrl, url);
		}
	}

})(jQuery, window.angular);