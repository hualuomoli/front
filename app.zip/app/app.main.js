require.config({
	baseUrl: '../app',
	paths: {
		'angular': '../bower_components/angular/angular.min',
		'angular-ui-router': '../bower_components/angular-ui-router/release/angular-ui-router.min',
		'angular-async-loader': '../bower_components/angular-async-loader/dist/angular-async-loader.min',

		'jquery': '../bower_components/jquery/dist/jquery.min',
		'bootstrap': '../bower_components/bootstrap/dist/js/bootstrap.min',
		'metisMenu': '../bower_components/metisMenu/dist/metisMenu.min'
	},
	shim: {
		'angular': {
			'exports': 'angular'
		},
		'angular-ui-router': {
			'deps': ['angular']
		},
		'angular-async-loader': {
			'deps': ['angular']
		},
		'bootstrap': {
			'deps': ['jquery']
		},
		'metisMenu': {
			'deps': ['jquery']
		}
	}
});

require(['angular', 'app.router'], function (angular) {
	angular.element(document).ready(function () {
		angular.bootstrap(document, ['app']);
		angular.element(document).find('html').addClass('ng-app');
	});
});