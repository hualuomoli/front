(function () {
	'use strict';

	angular.module('app')
		.directive('headerNotification', headerNotification);

	function headerNotification() {
		return {
			templateUrl: 'notification/notification.html',
			controller: 'notificationController',
			restrict: 'AE',
			replace: true
		}
	}
})();