(function (angular) {
	'use strict';

	angular.module('app')
		.service('notificationService', notificationService);

	/* @ngInject */
	function notificationService($http, commonService) {

		return {
			getAlerts: getAlerts,
			getTasks: getTasks,
			getMessage: getMessage
		}

		function getAlerts() {
			return commonService.getData('data/notification/alerts.json');
		}

		function getTasks() {
			return commonService.getData('data/notification/tasks.json');
		}

		function getMessage() {
			return commonService.getData('data/notification/messages.json');
		}

	}

})(window.angular);