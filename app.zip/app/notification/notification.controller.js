(function (angular) {
	'use strict';

	angular.module('app')
		.controller('notificationController', notificationController);

	/* @ngInject */
	function notificationController($scope, notificationService, userService) {
		$scope.alerts = {};
		$scope.messages = {};
		$scope.tasks = {};

		// if (userService.isLogin)
		getAll();

		//
		function getAll() {
			notificationService.getAlerts()
				.then(function (response) {
					$scope.alerts = response.data;
				});
			notificationService.getTasks()
				.then(function (response) {
					$scope.tasks = response.data;
				});
			notificationService.getMessage()
				.then(function (response) {
					$scope.messages = response.data;
				});
		};

	}

})(window.angular);