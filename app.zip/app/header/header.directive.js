(function () {
	'use strict';

	angular.module('app')
		.directive('header', header);

	function header() {
		return {
			templateUrl: 'header/header.html',
			restrict: 'AE',
			replace: true
		}
	}
})();